# Profile-Card
Live Demo 
[https://sudeshgowdq.github.io/Profile-Card/](https://sudeshgowdq.github.io/Profile-Card/)
I created pRofile card by ![Screenshot (72)](https://github.com/SUDESHGOWDQ/Profile-Card/assets/112839296/05b8a317-6440-4135-8744-6d4c5bb225f2)
the help of Html and Css and it was responsive and it was good looking i have used here color picker and font awsome icon all the box model properties
